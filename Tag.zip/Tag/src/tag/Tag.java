/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tag;
import java.net.*;
import java.util.*;
import java.io.*;
import com.jcraft.jsch.*;
/**
 *
 * @author thabo
 */
public class Tag {
	
	  
	
	  

	 /**
	  * @param args the command line arguments
	  */
	 public static void main(String[] args) {
		Login l = new Login();
		 l.setVisible(true);
		  
	 //  Login lg = new Login();
	//	lg.setVisible(true);
	/*    if(args.length != 3){
			 System.out.println("usage: ./sshbrute.jar [TARGET[:PORT]] [USERNAME] [WORDLIST]");
			 System.exit(1);
		}
		String targetIP;
		int targetPort;
		if(args[0].contains(":")){
			 targetIP = args[0].split(":")[0];
			 targetPort = Integer.parseInt(args[0].split(":")[1]);
		}else{
			 targetIP = args[0];
			 targetPort = 22;
		}
		checkHost(targetIP, targetPort);
		String user = args[1];
		ArrayList<String> wordlist = getWordlist(args[2]);
		System.out.println(String.format("cracking SSH pass for \"%s\" at %s...\n", user, targetIP));
		for(int i = 0; i < wordlist.size(); i++){
			 if(crackPass(targetIP, user, wordlist.get(i), targetPort)){
				  System.out.println("creds found: ");
				  System.out.println(String.format("\t user: %s ", user));
				  System.out.println(String.format("\t pass: %s ", wordlist.get(i)));
				  System.exit(0);
			 }
		}
		System.out.println("bruteforce failed");
    }
*/
   }
}
