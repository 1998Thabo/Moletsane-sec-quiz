/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tag;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.*;
import java.text.MessageFormat;
import javax.swing.JOptionPane;



/** 
 *
 * @author thabo
 */
public class Registration {
	 
 private int no_of_question;
	  private String question;
	  private String solution;
	  public Registration(int no_of_question, String question, String solution){
		   this.no_of_question = no_of_question;
		   this.question = question;
		   this.solution = solution;
	  }
	  
	  public int getid(){
		   return no_of_question;
	  } 
	  
	  public String get_question(){
		   return question;
	  }
	  
	  public String get_solution(){
		   return solution;
	  }	
	  
	  public String toStrong(){
		   return MessageFormat.format("{0} - {1} - {2}", getid(), get_question(), get_solution());
	  }
 try{
               String query = "INSERT INTO mathematics_question_and_answer(question) VALUES(?)";
               pstatement = con.prepareStatement(query);
               pstatement.setString(1, JOptionPane.showInputDialog(null, "enter your question"));
               //  pstatement.setString(2, dateFormatter.format((now)));
               pstatement.executeUpdate();
               JOptionPane.showMessageDialog(null, "saved");
          }catch(Exception e){
               JOptionPane.showMessageDialog(null, e);
          }
}
